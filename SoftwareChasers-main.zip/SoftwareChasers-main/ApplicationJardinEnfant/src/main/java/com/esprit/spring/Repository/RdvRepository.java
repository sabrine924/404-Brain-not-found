package com.esprit.spring.Repository;

public class RdvRepository {

}
