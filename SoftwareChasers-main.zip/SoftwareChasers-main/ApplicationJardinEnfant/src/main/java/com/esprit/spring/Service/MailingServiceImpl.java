package com.esprit.spring.Service;

public class MailingServiceImpl {

}
