package com.esprit.spring.Repository;

public class MailingRepository {

}
