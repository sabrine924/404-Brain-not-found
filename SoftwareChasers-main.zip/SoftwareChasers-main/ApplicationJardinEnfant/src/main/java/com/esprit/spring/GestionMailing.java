package com.esprit.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionMailing {

		public static void main(String[] args) {
			SpringApplication.run(GestionMailing.class, args);
		}

}
