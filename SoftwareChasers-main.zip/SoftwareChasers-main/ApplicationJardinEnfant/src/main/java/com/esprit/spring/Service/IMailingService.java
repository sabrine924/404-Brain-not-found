package com.esprit.spring.Service;

public class IMailingService {

}
