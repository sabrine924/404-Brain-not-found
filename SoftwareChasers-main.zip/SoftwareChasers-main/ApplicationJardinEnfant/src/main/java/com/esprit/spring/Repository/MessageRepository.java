package com.esprit.spring.Repository;

public class MessageRepository {

}
