package com.esprit.spring.Service;

public interface IEventService {

}
